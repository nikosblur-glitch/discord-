const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Set the welcome channel')
    .addChannelOption(opt => opt.setName('channel').setDescription('Welcome channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    db.prepare(`
      INSERT INTO settings (guild_id, welcome_channel) VALUES (?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET welcome_channel = excluded.welcome_channel
    `).run(interaction.guild.id, channel.id);
    await interaction.reply({ content: `Welcome channel set to ${channel}`, ephemeral: true });
  }
};
