const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    db.prepare('INSERT INTO warns (user_id, guild_id, moderator_id, reason) VALUES (?, ?, ?, ?)')
      .run(user.id, interaction.guild.id, interaction.user.id, reason);

    const count = db.prepare('SELECT COUNT(*) as c FROM warns WHERE user_id = ? AND guild_id = ?')
      .get(user.id, interaction.guild.id).c;

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('User Warned')
      .setDescription(`**${user.tag}** has been warned.\nReason: ${reason}\nTotal warns: **${count}**`);
    await interaction.reply({ embeds: [embed] });
  }
};
