const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('faq')
    .setDescription('FAQ system')
    .addSubcommand(sub => sub.setName('list').setDescription('List all FAQs'))
    .addSubcommand(sub => 
      sub.setName('add')
        .setDescription('Add a FAQ entry')
        .addStringOption(o => o.setName('question').setDescription('Question').setRequired(true))
        .addStringOption(o => o.setName('answer').setDescription('Answer').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('get')
        .setDescription('Get a specific FAQ')
        .addIntegerOption(o => o.setName('id').setDescription('FAQ ID').setRequired(true))
    ),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'list') {
      const rows = db.prepare('SELECT * FROM faq WHERE guild_id = ?').all(interaction.guild.id);
      if (rows.length === 0) return interaction.reply({ content: 'No FAQs yet.', ephemeral: true });
      const list = rows.map(r => `**#${r.id}** ${r.question}`).join('\n');
      const embed = new EmbedBuilder().setColor(0x5865F2).setTitle('FAQ List').setDescription(list);
      await interaction.reply({ embeds: [embed] });
    } else if (sub === 'add') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ content: 'No permission.', ephemeral: true });
      }
      const q = interaction.options.getString('question');
      const a = interaction.options.getString('answer');
      const info = db.prepare('INSERT INTO faq (guild_id, question, answer) VALUES (?, ?, ?)').run(interaction.guild.id, q, a);
      await interaction.reply({ content: `FAQ #${info.lastInsertRowid} added.`, ephemeral: true });
    } else if (sub === 'get') {
      const id = interaction.options.getInteger('id');
      const row = db.prepare('SELECT * FROM faq WHERE id = ? AND guild_id = ?').get(id, interaction.guild.id);
      if (!row) return interaction.reply({ content: 'FAQ not found.', ephemeral: true });
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(row.question)
        .setDescription(row.answer);
      await interaction.reply({ embeds: [embed] });
    }
  }
};
