const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system')
    .addSubcommand(sub => sub.setName('panel').setDescription('Send ticket panel'))
    .addSubcommand(sub => sub.setName('close').setDescription('Close current ticket'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'panel') {
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🎫 Support Tickets')
        .setDescription('Click the button below to create a support ticket.\nStaff will assist you as soon as possible.');
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('create_ticket').setLabel('Create Ticket').setStyle(ButtonStyle.Primary).setEmoji('🎫')
      );
      await interaction.reply({ embeds: [embed], components: [row] });
    } else if (sub === 'close') {
      await this.closeTicket(interaction, client);
    }
  },

  async createTicket(interaction, client) {
    const existing = db.prepare('SELECT * FROM tickets WHERE user_id = ? AND guild_id = ? AND status = ?')
      .get(interaction.user.id, interaction.guild.id, 'open');
    if (existing) {
      return interaction.reply({ content: `You already have an open ticket: <#${existing.channel_id}>`, ephemeral: true });
    }

    const settings = db.prepare('SELECT * FROM settings WHERE guild_id = ?').get(interaction.guild.id);
    const categoryId = settings?.ticket_category || process.env.TICKET_CATEGORY_ID;

    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, ''),
      type: ChannelType.GuildText,
      parent: categoryId || null,
      permissionOverwrites: [
        { id: interaction.guild.id, deny: [P.ViewChannel] },
        { id: interaction.user.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory] },
        { id: client.user.id, allow: [P.ViewChannel, P.SendMessages, P.ManageChannels] }
      ]
    });

    db.prepare('INSERT INTO tickets (channel_id, user_id, guild_id, type) VALUES (?, ?, ?, ?)')
      .run(channel.id, interaction.user.id, interaction.guild.id, 'support');

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('Ticket Created')
      .setDescription(`Welcome ${interaction.user}!\nPlease describe your issue.\nStaff will be with you shortly.`);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('close_ticket').setLabel('Close Ticket').setStyle(ButtonStyle.Danger)
    );
    await channel.send({ content: `${interaction.user}`, embeds: [embed], components: [row] });
    await interaction.reply({ content: `Ticket created: ${channel}`, ephemeral: true });
  },

  async closeTicket(interaction, client) {
    const ticket = db.prepare('SELECT * FROM tickets WHERE channel_id = ?').get(interaction.channel.id);
    if (!ticket) {
      return interaction.reply({ content: 'This is not a ticket channel.', ephemeral: true });
    }
    db.prepare('UPDATE tickets SET status = ? WHERE channel_id = ?').run('closed', interaction.channel.id);
    await interaction.reply('Closing ticket in 5 seconds...');
    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 5000);
  }
};
