const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings of a user')
    .addUserOption(opt => opt.setName('user').setDescription('User').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const rows = db.prepare('SELECT * FROM warns WHERE user_id = ? AND guild_id = ? ORDER BY timestamp DESC LIMIT 10')
      .all(user.id, interaction.guild.id);

    if (rows.length === 0) {
      return interaction.reply({ content: 'This user has no warnings.', ephemeral: true });
    }

    const list = rows.map((r, i) => `**${i + 1}.** ${r.reason} (<t:${r.timestamp}:R>)`).join('\n');
    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle(`Warnings for ${user.tag}`)
      .setDescription(list);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
