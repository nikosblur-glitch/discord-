const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('appeal')
    .setDescription('Submit a ban/mute appeal'),
  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('appeal_modal')
      .setTitle('Ban / Mute Appeal');

    const reason = new TextInputBuilder()
      .setCustomId('appeal_reason')
      .setLabel('Why should we unban/unmute you?')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1000);

    const extra = new TextInputBuilder()
      .setCustomId('extra_info')
      .setLabel('Any extra information')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(reason),
      new ActionRowBuilder().addComponents(extra)
    );

    await interaction.showModal(modal);
  }
};
