const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apply')
    .setDescription('Apply for staff or other positions'),
  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('application_modal')
      .setTitle('Staff Application');

    const q1 = new TextInputBuilder().setCustomId('age').setLabel('Your Age').setStyle(TextInputStyle.Short).setRequired(true);
    const q2 = new TextInputBuilder().setCustomId('experience').setLabel('Previous Experience').setStyle(TextInputStyle.Paragraph).setRequired(true);
    const q3 = new TextInputBuilder().setCustomId('why').setLabel('Why do you want to join?').setStyle(TextInputStyle.Paragraph).setRequired(true);
    const q4 = new TextInputBuilder().setCustomId('timezone').setLabel('Timezone / Availability').setStyle(TextInputStyle.Short).setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(q1),
      new ActionRowBuilder().addComponents(q2),
      new ActionRowBuilder().addComponents(q3),
      new ActionRowBuilder().addComponents(q4)
    );

    await interaction.showModal(modal);
  }
};
