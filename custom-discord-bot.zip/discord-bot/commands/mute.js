const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to mute').setRequired(true))
    .addIntegerOption(opt => opt.setName('minutes').setDescription('Duration in minutes').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (!member || !member.moderatable) {
      return interaction.reply({ content: 'I cannot mute this user.', ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);
    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('User Muted')
      .setDescription(`**${user.tag}** has been muted for **${minutes} minutes**.\nReason: ${reason}`);
    await interaction.reply({ embeds: [embed] });
  }
};
