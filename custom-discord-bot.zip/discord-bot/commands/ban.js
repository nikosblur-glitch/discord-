const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (member && !member.bannable) {
      return interaction.reply({ content: 'I cannot ban this user.', ephemeral: true });
    }

    await interaction.guild.members.ban(user.id, { reason });
    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('User Banned')
      .setDescription(`**${user.tag}** has been banned.\nReason: ${reason}`);
    await interaction.reply({ embeds: [embed] });
  }
};
