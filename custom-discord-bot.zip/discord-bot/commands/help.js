const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Shows all available commands'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🤖 Bot Commands')
      .setDescription('Here are the available command categories:')
      .addFields(
        { name: '🛡️ Moderation', value: '`/ban` `/kick` `/mute` `/unmute` `/warn` `/warnings` `/clear`', inline: false },
        { name: '🎫 Tickets', value: '`/ticket` `/close`', inline: false },
        { name: '📝 Applications', value: '`/apply` `/application-review`', inline: false },
        { name: '⚖️ Appeals', value: '`/appeal`', inline: false },
        { name: '❓ FAQ', value: '`/faq` `/faq-add`', inline: false },
        { name: '🎵 Music', value: '`/play` `/stop` `/skip` `/queue`', inline: false },
        { name: '🤖 AI', value: '`/ask` `/imagine` (needs API key)', inline: false },
        { name: '⚙️ Utility', value: '`/help` `/setwelcome` `/ping`', inline: false }
      )
      .setFooter({ text: 'Custom Bot for bot-hosting.net' });
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
