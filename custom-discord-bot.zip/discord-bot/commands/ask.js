const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ask')
    .setDescription('Ask the AI something')
    .addStringOption(opt => opt.setName('question').setDescription('Your question').setRequired(true)),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    await interaction.deferReply();

    if (!process.env.OPENAI_API_KEY) {
      return interaction.editReply({
        content: 'AI is not configured. Add OPENAI_API_KEY in .env to enable this command.\n\nYour question was: ' + question
      });
    }

    try {
      // Simple fetch to OpenAI (user must provide key)
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{ role: 'user', content: question }],
          max_tokens: 500
        })
      });
      const data = await res.json();
      const answer = data.choices?.[0]?.message?.content || 'No response from AI.';
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('AI Response')
        .setDescription(answer.slice(0, 4000));
      await interaction.editReply({ embeds: [embed] });
    } catch (e) {
      console.error(e);
      await interaction.editReply('Error contacting AI service.');
    }
  }
};
