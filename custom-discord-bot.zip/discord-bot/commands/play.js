const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');
const play = require('play-dl');

const queues = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play music from YouTube')
    .addStringOption(opt => opt.setName('query').setDescription('Song name or URL').setRequired(true)),
  async execute(interaction) {
    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: 'You need to be in a voice channel!', ephemeral: true });
    }

    await interaction.deferReply();
    const query = interaction.options.getString('query');

    try {
      let streamInfo;
      if (play.yt_validate(query) === 'video') {
        streamInfo = await play.video_info(query);
      } else {
        const search = await play.search(query, { limit: 1 });
        if (!search.length) return interaction.editReply('No results found.');
        streamInfo = await play.video_info(search[0].url);
      }

      const stream = await play.stream(streamInfo.video_details.url);
      const resource = createAudioResource(stream.stream, { inputType: stream.type });

      let connection = queues.get(interaction.guild.id)?.connection;
      if (!connection) {
        connection = joinVoiceChannel({
          channelId: voiceChannel.id,
          guildId: interaction.guild.id,
          adapterCreator: interaction.guild.voiceAdapterCreator
        });
      }

      const player = createAudioPlayer();
      connection.subscribe(player);
      player.play(resource);

      queues.set(interaction.guild.id, { connection, player, songs: [] });

      player.on(AudioPlayerStatus.Idle, () => {
        // simple: disconnect after idle
      });

      const embed = new EmbedBuilder()
        .setColor(0x57F287)
        .setTitle('Now Playing')
        .setDescription(`[${streamInfo.video_details.title}](${streamInfo.video_details.url})`)
        .setThumbnail(streamInfo.video_details.thumbnails[0]?.url);
      await interaction.editReply({ embeds: [embed] });
    } catch (e) {
      console.error(e);
      await interaction.editReply('Error playing the song. Make sure the bot has permissions and try a different link.');
    }
  }
};
