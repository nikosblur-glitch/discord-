const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove timeout from a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to unmute').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'User not found.', ephemeral: true });
    }

    await member.timeout(null);
    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('User Unmuted')
      .setDescription(`**${user.tag}** has been unmuted.`);
    await interaction.reply({ embeds: [embed] });
  }
};
