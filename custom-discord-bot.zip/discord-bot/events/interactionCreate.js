const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error(error);
        const msg = { content: 'There was an error while executing this command!', ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(msg).catch(() => {});
        } else {
          await interaction.reply(msg).catch(() => {});
        }
      }
    }

    if (interaction.isButton()) {
      if (interaction.customId === 'create_ticket') {
        const ticketCmd = client.commands.get('ticket');
        if (ticketCmd && ticketCmd.createTicket) {
          await ticketCmd.createTicket(interaction, client);
        }
      }
      if (interaction.customId === 'close_ticket') {
        const ticketCmd = client.commands.get('ticket');
        if (ticketCmd && ticketCmd.closeTicket) {
          await ticketCmd.closeTicket(interaction, client);
        }
      }
    }

    if (interaction.isModalSubmit()) {
      if (interaction.customId === 'application_modal') {
        const age = interaction.fields.getTextInputValue('age');
        const experience = interaction.fields.getTextInputValue('experience');
        const why = interaction.fields.getTextInputValue('why');
        const timezone = interaction.fields.getTextInputValue('timezone');
        const answers = JSON.stringify({ age, experience, why, timezone });

        db.prepare('INSERT INTO applications (user_id, guild_id, answers) VALUES (?, ?, ?)')
          .run(interaction.user.id, interaction.guild.id, answers);

        const embed = new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle('Application Submitted')
          .setDescription('Your staff application has been submitted successfully. Staff will review it soon.');
        await interaction.reply({ embeds: [embed], ephemeral: true });

        // Optional: notify staff channel if set
      }

      if (interaction.customId === 'appeal_modal') {
        const reason = interaction.fields.getTextInputValue('appeal_reason');
        const extra = interaction.fields.getTextInputValue('extra_info') || '';

        db.prepare('INSERT INTO appeals (user_id, guild_id, reason) VALUES (?, ?, ?)')
          .run(interaction.user.id, interaction.guild.id, reason + (extra ? '\n\n' + extra : ''));

        const embed = new EmbedBuilder()
          .setColor(0xFEE75C)
          .setTitle('Appeal Submitted')
          .setDescription('Your appeal has been submitted. Staff will review it.');
        await interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }
  }
};
