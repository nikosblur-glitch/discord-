const { EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const settings = db.prepare('SELECT * FROM settings WHERE guild_id = ?').get(member.guild.id);
    const channelId = settings?.welcome_channel || process.env.WELCOME_CHANNEL_ID;
    if (!channelId) return;

    const channel = member.guild.channels.cache.get(channelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('👋 Welcome!')
      .setDescription(`Welcome to **${member.guild.name}**, ${member}!\n\nWe hope you enjoy your stay.`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: `Member #${member.guild.memberCount}` })
      .setTimestamp();

    try {
      await channel.send({ embeds: [embed] });
    } catch (e) {
      console.error('Welcome error:', e);
    }
  }
};
