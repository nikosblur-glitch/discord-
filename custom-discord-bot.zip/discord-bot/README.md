# Custom Discord Bot

Ready-to-use Discord bot for **bot-hosting.net** with:

- **Moderation**: ban, kick, mute, unmute, warn, warnings, clear
- **Tickets / Support**: panel + create/close tickets
- **Applications**: staff application form (modal)
- **Appeals**: ban/mute appeal form
- **FAQ**: add / list / get FAQ entries
- **Music**: play (YouTube), stop
- **Welcome**: automatic welcome messages
- **AI**: /ask (requires OpenAI API key)
- **Utility**: help, ping, setwelcome

## Setup on bot-hosting.net

1. Upload this entire folder (or the zip) to your bot-hosting.net deployment.
2. Rename `.env.example` to `.env` and fill in:
   - `TOKEN` = your bot token (from Discord Developer Portal)
   - `CLIENT_ID` = your application client ID
   - `GUILD_ID` = your server ID (for faster command deploy)
3. In the panel run: `npm install`
4. Then run once: `node deploy-commands.js`
5. Start the bot with: `node index.js` (or set startup command to `node index.js`)

## Required Bot Permissions / Intents

Enable in Discord Developer Portal → Bot:
- Presence Intent (optional)
- Server Members Intent
- Message Content Intent

Invite the bot with permissions: Administrator (or carefully select: Manage Channels, Ban, Kick, Moderate Members, Manage Messages, Connect, Speak, etc.)

## Notes

- Music requires ffmpeg (included via ffmpeg-static).
- Database is SQLite (file `data/bot.db`) – works great on free hosting.
- AI command needs a valid OPENAI_API_KEY in .env.
- For production, consider adding more error handling and logging.
